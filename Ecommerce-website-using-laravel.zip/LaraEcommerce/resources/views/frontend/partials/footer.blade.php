<footer class="footer-bottom">
  <p class="text-center">&copy; 2019 All rights reserved | Ecommerce Site</p>
</footer>
