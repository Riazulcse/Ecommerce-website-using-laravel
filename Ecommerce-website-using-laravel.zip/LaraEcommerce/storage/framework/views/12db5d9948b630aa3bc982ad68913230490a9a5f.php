<?php $__env->startSection('content'); ?>
  <div class='container margin-top-20'>
    <h2>My Cart Items</h2>
    <?php if(App\Models\Cart::totalItems() > 0): ?>
      <table class="table table-bordered table-stripe">
        <thead>
          <tr>
            <th>No.</th>
            <th>Product Title</th>
            <th>Product Image</th>
            <th>Product Quantity</th>
            <th>Unit Price</th>
            <th>Sub total Price</th>
            <th>
              Delete
            </th>
          </tr>
        </thead>
        <tbody>
          <?php
          $total_price = 0;
          ?>
          <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($loop->index + 1); ?>

              </td>
              <td>
                <a href="<?php echo e(route('products.show', $cart->product->slug)); ?>"><?php echo e($cart->product->title); ?></a>
              </td>
              <td>
                <?php if($cart->product->images->count() > 0): ?>
                  <img src="<?php echo e(asset('images/products/'. $cart->product->images->first()->image)); ?>" width="60px">
                <?php endif; ?>
              </td>
              <td>
                <form class="form-inline" action="<?php echo e(route('carts.update', $cart->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="number" name="product_quantity" class="form-control" value="<?php echo e($cart->product_quantity); ?>"/>
                  <button type="submit" class="btn btn-success ml-1">Update</button>
                </form>
              </td>
              <td>
                <?php echo e($cart->product->price); ?> Taka
              </td>
              <td>
                <?php
                $total_price += $cart->product->price * $cart->product_quantity;
                ?>

                <?php echo e($cart->product->price * $cart->product_quantity); ?> Taka
              </td>
              <td>
                <form class="form-inline" action="<?php echo e(route('carts.delete', $cart->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="cart_id" />
                  <button type="submit" class="btn btn-danger">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="4"></td>
            <td>
              Total Amount:
            </td>
            <td colspan="2">
              <strong>  <?php echo e($total_price); ?> Taka</strong>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="float-right">
        <a href="<?php echo e(route('products')); ?>" class="btn btn-info btn-lg">Continue Shopping..</a>
        <a href="<?php echo e(route('checkouts')); ?>" class="btn btn-warning btn-lg">Checkout</a>
      </div>
    <?php else: ?>
      <div class="alert alert-warning">
        <strong>There is no item in your cart.</strong>
        <br>
        <a href="<?php echo e(route('products')); ?>" class="btn btn-info btn-lg">Continue Shopping..</a>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>