<div class="row">

  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-4">
      <div class="card">
        
        <?php $i = 1; ?>

        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($i > 0): ?>
              <a href="<?php echo route('products.show', $product->slug); ?>">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="<?php echo e($product->title); ?>" >
              </a>
          <?php endif; ?>

          <?php $i--; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="card-body">
          <h4 class="card-title">
            <a href="<?php echo route('products.show', $product->slug); ?>"><?php echo e($product->title); ?></a>
          </h4>
          <p class="card-text">Taka - <?php echo e($product->price); ?></p>
          <a href="#" class="btn btn-outline-warning">Add to cart</a>
        </div>
      </div>
    </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="mt-4 pagination">
  <?php echo e($products->links()); ?>

</div>
