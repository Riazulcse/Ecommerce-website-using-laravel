<?php $__env->startSection('content'); ?>
  <div class='container margin-top-20'>
    <h2>Contact Page</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi quidem saepe cum nihil velit illum atque corporis blanditiis, ipsa, expedita ad ea, ex ducimus enim ab. Modi non eveniet aperiam.</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>